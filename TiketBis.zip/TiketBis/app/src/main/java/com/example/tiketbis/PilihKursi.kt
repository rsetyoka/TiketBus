package com.example.tiketbis

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_login_menu.*
import kotlinx.android.synthetic.main.activity_login_menu.loginclick
import kotlinx.android.synthetic.main.activity_pilih_kursi.*

class PilihKursi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pilih_kursi)

        kursi1.setOnClickListener{
            val intent = Intent(this, DetailPesanan::class.java)
            startActivity(intent)
        }
    }
}