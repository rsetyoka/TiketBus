package com.example.tiketbis

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_list_bus.*
import kotlinx.android.synthetic.main.activity_login_menu.*

class ListBus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_bus)

        tiket1.setOnClickListener{
            val intent = Intent(this, PilihKursi::class.java)
            startActivity(intent)
        }
    }
}